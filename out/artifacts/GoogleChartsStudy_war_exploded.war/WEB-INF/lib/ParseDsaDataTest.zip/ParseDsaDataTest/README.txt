Screen scraper for the DsaDataTest page in OPNET AppInternals Xpert (aka Panorama)

DESCRIPTION:

      This utility parses metric samples from the HTML on a DSA Data Test query, then stores them in a MongoDB database and prints them to stdout. This utility can be used to preserve second-by-second live data samples before the DSA service consolidates that data into a single record for harvesting by the AppInternals Xpert server. 

REQUIREMENTS:

    * Java 1.6 or later
    * MongoDB

      Mongo DB Installation Summary:
         1. Download and extract a MongoDB package from http://www.mongodb.org/downloads
         2. cd to the directory where you extracted MongoDB
            For example,
            cd /Users/iandow/development/mongodb-osx-x86_64-1.6.5/
         3. cd bin
         4. mkdir data
         5. ./mongod --dbpath ./data 

    * Your classpath must contain the following components:
          o mongo-2.4.jar
          o jericho-html-3.1.jar
          o ParseDsaDataTest.jar 

USAGE:

   1. Navigate to the DsaDataTest on the managed node of your choice.
      For example, http://localhost:2111/DsaDataTest
   2. Follow the first link "DSA Data Tests" to get to the DSA Servlet Data Gather page.
   3. Fill in and select the appropriate fields to prepare your query, then click Submit.
   4. Copy and paste the resulting URL, and use it to run this utility, as follows:

      java ParseDsaDataTest <interval> <url>
            <interval> -- Polling interval in seconds, specified as an integer. Recommended 900 seconds, since DsaDataTest operates on a 15 minute buffer.
            <url> -- URL to a DsaDataTest metric query. 
      Example:
      java ParseDsaDataTest 900 http://192.168.0.12:2111/DsaDataTest?Test=rt&Metric=\DSA-win0ak\DA-Windows\1\\Processor\_Total\%25%20Processor%20Time 

      (Note, your shell or command prompt may require you to escape the backslashes in your URL.)



Sample Output:

      "epoch" : 1299115838 , "metric_value" : 4.6875
      "epoch" : 1299115839 , "metric_value" : 5.46875
      "epoch" : 1299115840 , "metric_value" : 2.34375
      "epoch" : 1299115841 , "metric_value" : 1.5625
      "epoch" : 1299115842 , "metric_value" : 1.5625
      "epoch" : 1299115843 , "metric_value" : 3.90625

