/*****************************************************************************************************************
 * Screen scraper for the DsaDataTest page in OPNET AppInternals Xpert (aka Panorama)
 *
 * DESCRIPTION:
 *       This utility parses metric samples from the HTML on a DSA Data Test query, then stores them in a MongoDB database and prints them to stdout. This utility can be used to preserve second-by-second live data samples before the DSA service consolidates that data into a single record for harvesting by the AppInternals Xpert server.
 *
 * REQUIREMENTS:
 *  * Java 1.6 or later
 *  * MongoDB
 *
 *      Mongo DB Installation Summary:
 *         1. Download and extract a MongoDB package from http://www.mongodb.org/downloads
 *         2. cd to the directory where you extracted MongoDB
 *            For example,
 *            cd /Users/iandow/development/mongodb-osx-x86_64-1.6.5/
 *         3. cd bin
 *         4. mkdir data
 *         5. ./mongod --dbpath ./data
 *
 *  * Your classpath must contain the following components:
 *      o mongo-2.4.jar
 *      o jericho-html-3.1.jar
 *      o ParseDsaDataTest.jar
 *
 * USAGE:
 *
 *    1. Navigate to the DsaDataTest on the managed node of your choice.
 *       For example, http://localhost:2111/DsaDataTest
 *    2. Follow the first link "DSA Data Tests" to get to the DSA Servlet Data Gather page.
 *    3. Fill in and select the appropriate fields to prepare your query, then click Submit.
 *    4. Copy and paste the resulting URL, and use it to run this utility, as follows:
 *
 *       java ParseDsaDataTest <interval> <url>
 *             <interval> -- Polling interval in seconds, specified as an integer. Recommended 900 seconds, since DsaDataTest operates on a 15 minute buffer.
 *             <url> -- URL to a DsaDataTest metric query.
 *       Example:
 *       java -cp jericho-html-3.1.jar:mongo-2.4.jar:ParseDsaDataTest.jar ParseDsaDataTest 10 "http://192.168.0.12:2111/DsaDataTest?Test=rt&Metric=\\DSA-wtn07018\\DA-Windows\\1\\\\Processor\\_Total\\%25%20Processor%20Time"

 *
 *
 * @author      Ian Downard, OPNET Technolgies, Inc.
 * <p>Last modified: March 2, 2011
 ****************************************************************************************************************/


import net.htmlparser.jericho.MasonTagTypes;
import net.htmlparser.jericho.MicrosoftTagTypes;
import net.htmlparser.jericho.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.io.*;


public class ParseDsaDataTest {
    public static void print_usage() {
        System.out.println("\nUsage : java ParseDsaDataTest <interval> <url>");
        System.out.print("\t<interval>	-- ");
        System.out.println("Polling interval in seconds, specified as an integer.  Recommended 900 seconds, since DsaDataTest operates on a 15 minute buffer.");
        System.out.print("\t<url>	-- ");
        System.out.println("URL to a DsaDataTest metric query.");
        System.out.println("Example : ");
        System.out.println("\tjava ParseDsaDataTest 900 \"http://192.168.0.12:2111/DsaDataTest?Test=rt&Metric=\\\\DSA-wtn07018\\\\DA-Windows\\\\1\\\\\\\\Processor\\\\_Total\\\\%25%20Processor%20Time\"");
        System.out.println("\tor\n\tjava -cp ./jericho-html-3.1.jar:./mongo-2.4.jar:./ParseDsaDataTest.jar ParseDsaDataTest 900 \"http://192.168.0.12:2111/DsaDataTest?Test=rt&Metric=\\\\DSA-wtn07018\\\\DA-Windows\\\\1\\\\\\\\Processor\\\\_Total\\\\%25%20Processor%20Time\"");

        System.exit(1);
    }

    public static void main(String[] args) throws InterruptedException, IOException {
        int sleep_time = 900;
        String sourceUrlString = "";
        //="http://192.168.0.12:2111/DsaDataTest?Test=rt&Metric=\\DSA-wtn07018\\DA-Windows\\1\\\\Processor\\_Total\\%25%20Processor%20Time";
        Source source=null;
        StreamedSource streamed_source = null;
        Integer last_update = 0;
        Integer epoch = 0;

        if (args.length!=2) {
            print_usage();
        } else {
            try {
                sleep_time=Integer.parseInt(args[0].trim());
                sourceUrlString = args[1].trim();
                source=new Source(new URL(sourceUrlString));
                streamed_source=new StreamedSource(new URL(sourceUrlString));
            } catch (NumberFormatException e) {
                e.printStackTrace();
                print_usage();
            } catch (MalformedURLException e) {
                e.printStackTrace();
                print_usage();
            } catch (IOException e) {
                e.printStackTrace();
                print_usage();
            }
        }
        do {
            if (sourceUrlString.indexOf(':')==-1) sourceUrlString="file:"+sourceUrlString;
            MicrosoftTagTypes.register();
            MasonTagTypes.register();

            //System.out.println("\n*******************************************************************************\n" + source);

            //System.out.println(source.getTextExtractor().setIncludeAttributes(true).toString());

            BufferedReader here = new BufferedReader(new StringReader(source.toString()));
            String thisLine;

            MongoInterface my_mongo = new MongoInterface("127.0.0.1");


            while ((thisLine = here.readLine()) != null) {

                thisLine = thisLine.replaceAll("&#58;",":");
                //System.out.println(thisLine);
                //for each line in source, if line starts with <TR>, parse our data.
                Pattern pattern = Pattern.compile("<TR> <TD>\\d*</TD> <TD>(\\d*) \\([^)]*\\)</TD> <TD>DATA</TD> <TD>([\\d\\.]*).*");
                Matcher matcher = pattern.matcher(thisLine);
                /*if(matcher.matches()) {
                    System.out.println(matcher.group(1));
                }*/
                if(matcher.find()) {

                    /*String result = "answer: ";
                    for (int i = 1; i<= matcher.groupCount(); i++) {
                        result += matcher.group(i) + " ";
                    }
                    System.out.println(result);
                    */
                    if (matcher.groupCount() == 2) {
                        epoch = new Integer(matcher.group(1));
                        Double metric_value = new Double(matcher.group(2));
                        if (epoch > last_update)
                            System.out.println("\"epoch\" : " + epoch + " , \"metric_value\" : " + metric_value);
                        my_mongo.Insert(epoch, metric_value);
                    }
                }
            }
            last_update = epoch;
            //my_mongo.PrintDB();
            //System.out.println("Total metric samples stored: " + my_mongo.coll.getCount());
            //String serverStatus_output = my_mongo.db.command("serverStatus").get("mem").toString();
            //System.out.println(serverStatus_output);

            Thread.currentThread().sleep(1000*sleep_time);

            source=new Source(new URL(sourceUrlString));
            streamed_source=new StreamedSource(new URL(sourceUrlString));
        } while(true);
    }
}
