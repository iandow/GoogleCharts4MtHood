import com.mongodb.Mongo;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.BasicDBObject;
import com.mongodb.DBCursor;

import java.net.UnknownHostException;


/**
 * Created by IntelliJ IDEA.
 * User: idownard
 * Date: Dec 3, 2010
 * Time: 12:07:25 AM
 * To change this template use File | Settings | File Templates.
 */
public class MongoInterface {

    static boolean VERBOSE = true;
    static boolean INSERT_DATA = true;
    protected DB db;
    protected DBCollection coll;

    MongoInterface(String server_id) {
        //Mongo m = new Mongo( "192.168.0.18" , 27017 );
        Mongo m = null;
        try {
            m = new Mongo( server_id , 27017 );
        } catch (UnknownHostException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }

        db = m.getDB("DsaMetricData");
        coll = db.getCollection("metricValues");  //a collection is like a table
    }
    public void Insert (Integer epoch, Double metric_value) {
        BasicDBObject dbObj = new BasicDBObject();
        BasicDBObject query = new BasicDBObject();
        query.put("epoch",epoch);
        if ( (coll.find(query)).count() == 0) {
            dbObj.put("epoch", epoch);
            dbObj.put("metric_value", metric_value);
            coll.insert(dbObj);
        }
    }

    public void PrintDB () {
        DBCursor cur = coll.find();
        while(cur.hasNext()) {
            if (VERBOSE)
                System.out.println(cur.next());
            else
                cur.next();
        }
    }
}
